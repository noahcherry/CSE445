#include <stdio.h>
#include <unistd.h>
#define MAX 17
typedef char line[MAX];

/* sbox eval system
 *
 */
int boxcheck(char a, char b, char c, char d, int box, char in[]) {
	//box passed 
	if(in[0+box] == a && in[1+box] == b && in[2+box] == c && in[3+box] == d)
		return 1;
	return 0;
}

/* in - 16 'bits'(chars) to be evaluated
 * box - 4 boces eval 4 bits each, this selects the box in use
 * 
 */
char substitute(char in[], int box) {
	box *= 4;
	//box passed 0
	if(boxcheck('0', '0', '0', '0', box, in)) {
		in[0+box] = '1'; 
		in[1+box] = '1';
		in[2+box] = '1';
		in[3+box] = '0';
		return 0;
	}
	//box passed 1
	if(boxcheck('0', '0', '0', '1', box, in)) {
		in[0+box] = '0'; 
		in[1+box] = '1';
		in[2+box] = '0';
		in[3+box] = '0';
		return 0;
	}
	//box passed 2
	if(boxcheck('0', '0', '1', '0', box, in)) {
		in[0+box] = '1'; 
		in[1+box] = '1';
		in[2+box] = '0';
		in[3+box] = '1';
		return 0;
	}
	//box passed 3
	if(boxcheck('0', '0', '1', '1', box, in)) {
		in[0+box] = '0'; 
		in[1+box] = '0';
		in[2+box] = '0';
		in[3+box] = '1';
		return 0;
	}
	//box passed 4
	if(boxcheck('0', '1', '0', '0', box, in)) {
		in[0+box] = '0'; 
		in[1+box] = '0';
		in[2+box] = '1';
		in[3+box] = '0';
		return 0;
	}
	//box passed 5
	if(boxcheck('0', '1', '0', '1', box, in)) {
		in[0+box] = '1'; 
		in[1+box] = '1';
		in[2+box] = '1';
		in[3+box] = '1';
		return 0;
	}
	//box passed 6
	if(boxcheck('0', '1', '1', '0', box, in)) {
		in[0+box] = '1'; 
		in[1+box] = '0';
		in[2+box] = '1';
		in[3+box] = '1';
		return 0;
	}
	//box passed 7
	if(boxcheck('0', '1', '1', '1', box, in)) {
		in[0+box] = '1'; 
		in[1+box] = '0';
		in[2+box] = '0';
		in[3+box] = '0';
		return 0;
	}
	//box passed 8
	if(boxcheck('1', '0', '0', '0', box, in)) {
		in[0+box] = '0'; 
		in[1+box] = '0';
		in[2+box] = '1';
		in[3+box] = '1';
		return 0;
	}
	//box passed 9
	if(boxcheck('1', '0', '0', '1', box, in)) {
		in[0+box] = '1'; 
		in[1+box] = '0';
		in[2+box] = '1';
		in[3+box] = '0';
		return 0;
	}
	//box passed 10
	if(boxcheck('1', '0', '1', '0', box, in)) {
		in[0+box] = '0'; 
		in[1+box] = '1';
		in[2+box] = '1';
		in[3+box] = '0';
		return 0;
	}
	//box passed 11
	if(boxcheck('1', '0', '1', '1', box, in)) {
		in[0+box] = '1'; 
		in[1+box] = '1';
		in[2+box] = '0';
		in[3+box] = '0';
		return 0;
	}
	//box passed 12
	if(boxcheck('1', '1', '0', '0', box, in)) {
		in[0+box] = '0'; 
		in[1+box] = '1';
		in[2+box] = '0';
		in[3+box] = '1';
		return 0;
	}
	//box passed 13
	if(boxcheck('1', '1', '0', '1', box, in)) {
		in[0+box] = '1'; 
		in[1+box] = '0';
		in[2+box] = '0';
		in[3+box] = '1';
		return 0;
	}
	//box passed 14
	if(boxcheck('1', '1', '1', '0', box, in)) {
		in[0+box] = '0'; 
		in[1+box] = '0';
		in[2+box] = '0';
		in[3+box] = '0';
		return 0;
	}
	//box passed 15
	if(boxcheck('1', '1', '1', '1', box, in)) {
		in[0+box] = '0'; 
		in[1+box] = '1';
		in[2+box] = '1';
		in[3+box] = '1';
		return 0;
	}

	return 0;
}

/* swap binary values according to permutation table
 * 2 & 5
 * 3 & 9
 * 4 & 13
 * 7 & 10
 * 8 & 14
 * 1, 6, 11, and 16 do NOT get swapped
 */
char permutation(char in[])
{
	char safePlace = in[2];
	in[2] = in[5];
	in[5] = safePlace;

	safePlace = in[3];
	in[3] = in[9];
	in[9] = safePlace;

	safePlace = in[4];
	in[4] = in[13];
	in[13] = safePlace;

	safePlace = in[7];
	in[7] = in[10];
	in[10] = safePlace;

	safePlace = in[8];
	in[8] = in[14];
	in[14] = safePlace;

	return 0;
}

int keymix(char in[],char k[]) {
	int i;
	for(i = 0; i < 17; i++){
		if((in[i] == '1' && k[i] == '0') ||(in[i] == '0' && k[i] == '1'))
			in[i] = '1';
		else
			in[i] = '0';
	}

	return 0;
}

int main(int argc, char* argv[]) {
	line text = "1111111111111111";
	line key = "0101010101010101";

	opterr =

	//TODO wrap in getopt
	//add decrypt substitute
	keymix(text, key);

	substitute(text, 0);
	substitute(text, 1);
	substitute(text, 2);
	substitute(text, 3);
	permutation(text);
	keymix(text, key);

	substitute(text, 0);
	substitute(text, 1);
	substitute(text, 2);
	substitute(text, 3);
	permutation(text);
	keymix(text, key);

	substitute(text, 0);
	substitute(text, 1);
	substitute(text, 2);
	substitute(text, 3);
	permutation(text);
	keymix(text, key);


	substitute(text, 0);
	substitute(text, 1);
	substitute(text, 2);
	substitute(text, 3);
	keymix(text, key);


	text[17] = '\0';
	printf("\n%s\n", text);

	return 0;
}